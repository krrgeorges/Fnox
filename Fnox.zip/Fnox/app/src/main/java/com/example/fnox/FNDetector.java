package com.example.fnox;


import android.content.Context;
import android.os.Environment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import edu.stanford.nlp.ie.AbstractSequenceClassifier;
import edu.stanford.nlp.ie.crf.CRFClassifier;
import edu.stanford.nlp.ling.CoreLabel;

//import edu.stanford.nlp.ie.AbstractSequenceClassifier;
//import edu.stanford.nlp.ie.crf.CRFClassifier;
//import edu.stanford.nlp.ling.CoreLabel;
//import edu.stanford.nlp.tagger.maxent.MaxentTagger;

public class FNDetector {
    private String text,type;
    int GS_WINDOW_SIZE = 5;
    Context c;

    //locally targeted
    private String[] news_sources = {"indiatoday","economictimes","mirror","firstpost",
            "thehindu","ndtv","livemint","news18","financialexpress","cnbctv18"}; // needs more for global impact
    //collect by country
    //ranked news sources?

    FNDetector(Context c, String text, String type){
        this.c = c;
        this.text = text;
        this.type = type; // RR WD WR
    }

    public void detect(){
        // take text

        // 1. direct search
        this.gpq(this.text);

        // 2.remove adjectives adverbs verbs and all, keep nouns and unknowns and just search those tokens

        // 2.2 Use Custom to identify
//        ArrayList<String> candidate_tokens = this.customPOS();
//        this.gspq(candidate_tokens);

        // 3. Do NER to take tokens. Just search those tokens
//        ArrayList<String> candidate_tokens = this.obtainSNER();
//        this.gspq(candidate_tokens);

    }

    private ArrayList<Object> gpq(String text){
        String qt = '"'+text+'"';
        String url = this.gs_template(qt);
        return this.gatherNews(url);
    }

    private ArrayList<Object> gspq(ArrayList<String> tokens){
        String qt = "";
        for(String token:tokens){
            qt+= '"'+token+'"'+" ";
        }
        qt = qt.trim();
        String url = this.gs_template(qt);
        return this.gatherNews(url);
    }

    private boolean matchLinkWithVS(String link){
        String domain;
        try {
            domain = new URL(link).getHost();
        } catch (MalformedURLException ex) {
            return false;
        }
        for(String vs:this.news_sources){
            if(domain.contains(vs) == true){
                return true;
            }
        }
        return false;
    }

    private String gs_template(String qt){
        if(this.type.equals("WD")){ // week sort by date
            return "https://www.google.com/search?biw=871&bih=608&tbs=sbd%3A1%2Cqdr%3Aw&tbm=nws&ei=TRDKXuKEBKPWz7sP8a--yAM&q="+qt;
        }
        else if(this.type.equals("WR")){ // week sort by relevance
            return "https://www.google.com/search?tbm=nws&tbs=qdr:w&sa=X&ved=0ahUKEwj3pLKZ7svpAhVx73MBHTHJDiUQpwUIJA&biw=869&bih=608&q="+qt;
        }
        else{ // recent sort by relevance
            return "https://www.google.com/search?tbm=nws&sxsrf=ALeKk02_WlQ3-UmgR-Kkam-txm5hYkCt0g%3A1590296240215&ei=sP7JXqvnDPTYz7sPvu2U4AI&q="+qt;
        }
    }

    private String retrievePOSModel(){
        try {
            File file = new File(Environment.getDownloadCacheDirectory()+"/english-bidirectional-distsim.tagger");
            if(file.exists() == false) {
                FileOutputStream f = new FileOutputStream(file);
                BufferedReader br = new BufferedReader(new InputStreamReader(c.getAssets().open("pos_model_fnox/english-bidirectional-distsim.tagger")));
                String content = "";
                String o = "";
                while ((o = br.readLine()) != null) {
                    content += o;
                }
                f.write(content.getBytes());
                f.close();
            }
            return Environment.getDownloadCacheDirectory()+"/english-bidirectional-distsim.tagger";
        } catch (Exception e) {
            return "";
        }
    }

    private String retrieveNERClassifier(){
        try {
            File file = new File(Environment.getDownloadCacheDirectory()+"/english.muc.7class.distsim.crf.ser.gz");
            if(file.exists() == false) {
                FileOutputStream f = new FileOutputStream(file);
                BufferedReader br = new BufferedReader(new InputStreamReader(c.getAssets().open("ner_classifier_fnox/english.muc.7class.distsim.crf.ser.gz")));
                String content = "";
                String o = "";
                while ((o = br.readLine()) != null) {
                    content += o;
                }
                f.write(content.getBytes());
                f.close();
            }
            return Environment.getDownloadCacheDirectory()+"/english.muc.7class.distsim.crf.ser.gz";
        } catch (Exception e) {
            return "";
        }
    }

    private ArrayList<String> obtainSNER(){
        try {
            ArrayList<String> results = new ArrayList<>();
            AbstractSequenceClassifier<CoreLabel> classifier = CRFClassifier.getClassifier(this.retrieveNERClassifier());
            ArrayList<String> sentences = this.sentence_tokenize();
            for(String sentence:sentences){
                String res = classifier.classifyToString(sentence, "slashTags", false);
                String[] splits = res.split(" ");
                for(String s:splits){
                    if(s.contains("/") == true){
                        // Location, Person, Organization, Money, Percent
                        String[] splits1 = s.split("/");
                        String word = splits1[0];
                        String tag = splits1[splits1.length-1];
                        if(tag.contains("LOCATION") || tag.contains("PERSON") || tag.contains("ORGANIZATION") || tag.contains("MONEY") || tag.contains("PERCENT")){
                            if(results.contains(word) == false) {
                                results.add(word);
                            }
                        }
                    }
                }
            }
            return results;
        } catch (Exception e) {
            return new ArrayList<String>();
        }
    }

    private JSONObject retrieveCPOSData(){
        JSONObject jobj = new JSONObject();
        try{
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getAssets().open("pos_list.json")));
            String o = "";
            String content = "";
            while((o = br.readLine())!=null){
                content += o;
            }

            return new JSONObject(content);
        }
        catch(Exception e){
            return jobj;
        }
    }

    private ArrayList<String> customPOS(){
        ArrayList<String> candidate_tokens = new ArrayList<>();

        ArrayList<String> tokens = this.tokenize(true);
        JSONObject jobj = this.retrieveCPOSData();

        for(String token:tokens){
            try {
                JSONArray s = jobj.getJSONArray(token);
                for(int i=0;i<=s.length()-1;i++){
                    try {
                        if((s.getString(i).toLowerCase().contains("noun") == true && s.getString(i).toLowerCase().contains("pronoun") == false)){
                            candidate_tokens.add(token);
                        }
                    } catch (JSONException e) {
                        continue;
                    }
                }
            } catch (JSONException e) {
                candidate_tokens.add(token);
            }
        }
        return candidate_tokens;
    }

    private ArrayList<String> sentence_tokenize(){
        String temp_text = this.text;
        String symbols = "!@^&*()_+-={}|:<>?[]\\;',./'";
        for(int i=0;i<=symbols.length()-1;i++){
            String symbol = String.valueOf(symbols.charAt(i));
            temp_text = temp_text.replace(symbol," "+symbol+" ");
        }
        String[] splits = temp_text.split(".|!|//?");
        ArrayList<String> sentences = new ArrayList<>();
        for(String s:splits){
            sentences.add(s);
        }
        return sentences;
    }

    private ArrayList<String> tokenize(boolean shouldBeLowerCase){
        String temp_text = this.text;
        ArrayList<String> tokens = new ArrayList<String>();
        String symbols = "!@^&*()_+-={}|:<>?[]\\;',./'";
        for(int i=0;i<=symbols.length()-1;i++){
            String symbol = String.valueOf(symbols.charAt(i));
            temp_text = temp_text.replace(symbol," "+symbol+" ");
        }
        if(shouldBeLowerCase == true) {
            temp_text = temp_text.toLowerCase();
        }
        String[] splits = temp_text.split(" ");
        for(int i=0;i<=splits.length-1;i++){
            if(tokens.contains(splits[i]) == false) {
                tokens.add(splits[i]);
            }
        }
        return tokens;
    }

    private boolean monthMatch(String datetext){
        String[] months = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
        for(String month:months){
            if(datetext.contains(month) == true){
                return true;
            }
        }
        return false;
    }

    private ArrayList<Object> gatherNews(String source_url){
        LinkedHashMap<String,ArrayList<String>> news = new LinkedHashMap();
        Document doc;

        for(int i=0;i<=this.GS_WINDOW_SIZE-1;i++){
            try {
                doc = Jsoup.parse(new URL(source_url.replace(" ", "+")+"&start="+(i*10)), 30000);
            } catch (Exception ex) {
                return new ArrayList<Object>(){{add(0);add(new LinkedHashMap<String,ArrayList<String>>());}};
            }
            Elements elems = doc.getElementsByTag("a");
            for(Element elem:elems){
                String link = elem.attr("href");
                if(this.matchLinkWithVS(link) == true && news.containsKey(elem.attr("href")) == false && elem.text().trim().length() > 0 && elem.text().trim().split(" ").length > 3){
                    ArrayList<String> mdata = new ArrayList<String>();

                    String text = elem.text().trim();
                    String date = "";

                    Element topParent = elem.parent().parent();
                    Elements spans = topParent.getElementsByTag("span");
                    for(Element span:spans){
                        if( (span.text().trim().split(" ").length == 3 && (span.text().contains(" hours ago") || span.text().contains(" mins ago") || span.text().contains(" secs ago"))) || (span.text().trim().split("-").length == 3 && this.monthMatch(span.text().trim()) == true)  ){
                            date = span.text().trim();
                            break;
                        }
                    }
                    mdata.add(text);
                    mdata.add(date);

                    System.out.println(text);

                    news.put(link, mdata);
                }
            }
        }

        final LinkedHashMap<String,ArrayList<String>> mnews = news;

        return new ArrayList<Object>(){{add(1);add(mnews);}};
    }


}